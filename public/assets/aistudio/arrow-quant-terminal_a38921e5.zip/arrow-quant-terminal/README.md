# Arrow Quant Terminal (UK Desk Edition)

A high-performance, ultra-clean institutional trading terminal and trade journal inspired by London quantitative desks and Termux monochrome ergonomics.

## 🚀 Key Features

- **Monochrome Institutional UI**: High-contrast pure black-and-white (`#000000` / `#ffffff`) aesthetic with no visual clutter.
- **Audited Desk Signals & Archive**: Live desk alerts and searchable historical performance ledger with outcomes (`TP2_HIT`, `TP1_HIT`, `BREAKEVEN`, `SL_HIT`).
- **Automated Trading Journal**:
  - Auto-generated UTC timestamp + date.
  - 42 tradable instruments directory (Forex, Crypto, Commodities, Indices, UK Equities).
  - Link trades directly to active desk signals.
  - Tracks Direction, Entry, Exit, Lots, P&L (£), R:R, and 5-star discipline ratings.
  - Zero-backend `localStorage` persistence.
  - 1-click CSV trade export.
- **User Dashboard & Authentication**:
  - Sign in / Sign up with instant 1-click Demo mode.
  - Real-time trader win rate, profit factor, and risk/reward metrics.
- **Precision Lot Size & Risk Calculator**: Dynamic pip and risk calculation in GBP (`£`).
- **Legal Compliance**: Full UK Financial Disclaimer, Terms of Service, and Privacy Policy.

---

## 💻 How to Run

### Option 1: Instant Server (Zero Install)
The production bundle is already compiled in `./dist`. You can serve it directly with Node.js:
```bash
node server.mjs
```
Then visit:
`http://localhost:5173` or `http://localhost:8080`

### Option 2: Development Mode (Vite)
```bash
npm install
npm run dev
```

### Option 3: Production Build
```bash
npm run build
```
